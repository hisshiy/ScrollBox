﻿using UnityEngine;
using System.Collections;

public class start : MonoBehaviour {

		public void SceneLoad (){
			Application.LoadLevel ("game");//ゲーム画面の読み込み
		}
}
