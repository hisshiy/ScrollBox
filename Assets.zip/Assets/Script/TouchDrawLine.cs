﻿using UnityEngine;
using System.Collections.Generic;

public class TouchDrawLine : MonoBehaviour {

	public GameObject linePrefab2;
	public float lineLength = 0.2f;
	public float lineWidth = 0.1f;
	public Vector3 touchPos;
	public Vector3 endPos;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.touchCount > 0) {//タッチされたかどうか
			Touch touch = Input.GetTouch (0);
			if (touch.phase == TouchPhase.Began) {//タッチ開始
				touchPos = Camera.main.ScreenToWorldPoint (touch.position);
				touchPos.z=0;
			}
			if (touch.phase == TouchPhase.Moved) {//タッチ移動
				//Debug.Log("touch" + touch.position);
				endPos = Camera.main.ScreenToWorldPoint(touch.position);//タッチが終わった点を取得する
				//Debug.Log("end" + endPos);
				endPos.x = endPos.x+600;
				endPos.z = 0;

				Vector3 CurrentPos = Input.GetTouch (0).position;
				Vector3 DeltaPosition = Input.GetTouch (0).deltaPosition;
				Vector3 pp = endPos + DeltaPosition;
				//Debug.Log("CurrentPos" + CurrentPos + "DeltaPos" + DeltaPosition + "pp" + pp);
				GameObject obj = Instantiate (linePrefab2, transform.position, transform.rotation) as GameObject;


				obj.transform.localPosition = endPos;
				obj.transform.right = (endPos).normalized;
				//obj.transform.localScale = new Vector3( endPos.magnitude, lineWidth , lineWidth );
				obj.transform.parent = this.transform;
//				GameObject obj = Instantiate(linePrefab2, transform.position, transform.rotation) as GameObject;//オブジェクトの配置
//				obj.transform.position = (endPos+touchPos)/2;//
//				obj.transform.right = (touchPos-endPos).normalized;//正規化
//
//				obj.transform.localScale = new Vector3( (touchPos-endPos).magnitude, lineWidth , lineWidth );
//
//				obj.transform.parent = this.transform;

				touchPos = endPos;
				
			}
			if (touch.phase == TouchPhase.Ended) {//タッチ終了
			}

		}
	}
	void TouchMoved (Vector3 CurrentPos ,Vector3 DeltaPosition)
	{       
		Debug.Log("CurrentPos" + CurrentPos + "DeltaPos" + DeltaPosition);
	}
}
