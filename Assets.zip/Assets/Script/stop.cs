﻿using UnityEngine;
using System.Collections;

public class stop : MonoBehaviour {
	private int count = 0;//止まっているかどうか判断する値
	public Texture button1;
	public Texture button2;
	public Texture button3;
	public void ButtonPush() {
		if (count == 0) {//時間が動いている場合
			Time.timeScale = 0;//止める
			count = 1;
		}else if(count == 1){//時間が止まっている場合
			Time.timeScale = 1;//動かす
			count = 0;
		}

	}
	void OnGUI () {
		// ボタンを表示する
		if (count == 1) {//時間が止まっている時
			GUI.Box (new Rect (0,0,Screen.width,Screen.height), "");//ボックス（ポーズ画面の背景の設定）
			GUI.backgroundColor = Color.black;//GUIの色を黒に変更
			if (GUI.Button (new Rect (Screen.width / 2 - 250, Screen.height / 2 - 300, 500, 140), button1)) {
				Time.timeScale = 1;//動かす
				count = 0;//カウントを戻す
			}//押すと時間を動かす
			if (GUI.Button (new Rect (Screen.width / 2 - 250, (Screen.height / 2 - 100), 500, 140), button2)) {
				Application.LoadLevel("game");//現在のシーンの再読み込み
				Time.timeScale = 1;//動かす
				count = 0;//カウントを戻す
			}//押すと画面再読み込みして、動かす
			if(GUI.Button(new Rect(Screen.width/2 - 250, (Screen.height/2 + 100), 500, 140), button3)){
				Application.LoadLevel("title");//タイトル画面を読み込む
				Time.timeScale = 1;//動かす
				count = 0;//カウントを戻す
			}//押すとメニュー画面に遷移
		}
	}
}
