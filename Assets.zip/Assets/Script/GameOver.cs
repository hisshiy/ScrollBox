﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GameOver : MonoBehaviour {
	//MessageText
	public Text messageText;

	private void OnTriggerEnter2D(Collider2D other){
		//メッセージを変更
		messageText.text = "GAME OVER";
		//メッセージを用事
		messageText.gameObject.SetActive(true);
		//シーンの読込
		StartCoroutine(WaitAndReloadScene());
	}

	IEnumerator WaitAndReloadScene() {
		//２秒停止
		yield return new WaitForSeconds(2.0f);
		//シーンの再読込
		Application.LoadLevel("title");
	}
}
