﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class Goal : MonoBehaviour {

	public Text messageText;

	private void OnTriggerEnter2D(Collider2D other){
		//衝突判定
		//メッセージを変更
		messageText.text = "STAGE CLEAR";
		//メッセージを表示
		messageText.gameObject.SetActive(true);
		//シーンの読込
		StartCoroutine(WaitAndReloadScene());
	}

	IEnumerator WaitAndReloadScene() {
		//２秒停止
		yield return new WaitForSeconds(2.0f);
		//シーンの再読込
		Application.LoadLevel("title");
	}
}
