﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class ClickDrawLine: MonoBehaviour
{

	public GameObject linePrefab;//オブジェクト指定
	public float lineLength = 0.5f;//線の長さ
	public float lineWidth = 0.2f;//線の太さ
	private Vector3 touchPos;//画面をタッチした際の座標
	private Vector3 startPos;//画面をタッチした際の座標
	private int flag = 0;//線を引くかどうかの判定
	private int flag2 = 0;//線を引くかどうかの判定
	private Rigidbody2D rb;
	private float ink=1;
	Slider slider;//かける線の量
	void Start(){//起動時
		rb = this.GetComponent<Rigidbody2D>();
		slider = GameObject.Find("Slider").GetComponent<Slider>();//スライダーの取得
	}

	void Update (){//毎フレーム実行
		drawLine ();//線を描く
	}

	void drawLine(){//線を引くメソッド

		if(Input.GetMouseButtonDown(0))//もしマウスが押されたら
		{
			touchPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);//マウスの座標取得（ワールド座標）
			touchPos.z=0;//奥行きを無くす
			Collider2D aCollider2d = Physics2D.OverlapPoint(touchPos);//指定した点がColliderの領域内に含まれているか
			if (aCollider2d) {//もしタッチした点がオブジェクトの上なら
				flag = 1;//線を引かない
			}else{//それ以外なら
				flag = 0;//線を引く
			}
		}

		if(Input.GetMouseButton(0))//マウスが押されている間
		{
			
			if(Time.timeScale != 0){//時間が止まっていない間
				startPos = touchPos;//始点の取得
				Vector3 endPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);//マウスの座標取得（ワールド座標）
				endPos.z=0;//奥行きは無くす
				Collider2D aCollider2d = Physics2D.OverlapPoint(endPos);//指定した点がColliderの領域内に含まれているか
				if (aCollider2d) {//もしタッチの終点がオブジェクトの上なら
					flag2 = 1;//線を引かない
				} else {
					flag2 = 0;//線を引く
				}
				if ((endPos - startPos).magnitude > lineLength) {//もし長さが最低限を超えていたら
					if(flag==0 && flag2 == 0 && ink>0){//線を引く
						GameObject obj = Instantiate (linePrefab, transform.position, transform.rotation) as GameObject;//オブジェクトの配置
						obj.transform.position = (startPos + endPos) / 2;//線の座標
						obj.transform.right = (endPos - startPos).normalized;//正規化
					
						obj.transform.localScale = new Vector3 ((endPos - startPos).magnitude, lineWidth, lineWidth);//オブジェクトのローカルなサイズ

						obj.transform.parent = this.transform;//スクリプトで設定したオブジェクトを、スクリプトを実行するオブジェクトの子オブジェクトとして設定

						touchPos = endPos;
						Destroy (obj, 5f);//５秒後に削除
						ink -= 0.013f;//スライダーのゲージを減らす
						slider.value = ink;//スライダーに反映
						Invoke("inkReturn", 5f);//線が消えたタイミングでゲージを増やす
					}
				}
			}
		}
	}
	void inkReturn(){
		ink += 0.013f;//スライダーのゲージを増やす
		slider.value = ink;//スライダーに反映
	}

}
