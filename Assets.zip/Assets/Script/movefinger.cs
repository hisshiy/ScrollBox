﻿using UnityEngine;
using System.Collections;

public class movefinger : MonoBehaviour {

	Vector3 startPos;//初期位置
	Vector3 startfingerPos;//初期の指先位置
	Vector3 fingerPos;//指先の位置
	float time;//時間
	public GameObject line;//誘導線
	public float lineWidth = 0.2f;//線の太さ

	// Use this for initialization
	void Start () {//起動した時
		startPos = transform.position;//現在の位置
		startfingerPos = new Vector3((transform.position.x-0.6f),(transform.position.y-1.4f),0f);//現在の位置を記憶
		fingerPos = new Vector3((transform.position.x-0.6f),(transform.position.y-1.4f),0f);//指先の位置
		time = 0;//時間を初期化
	}
	
	// Update is called once per frame
	void Update () {//毎フレーム実行
		time += Time.deltaTime;//経過時間
		transform.position += new Vector3(8f*Time.deltaTime, 4f*Time.deltaTime, 0f);//時間によって座標移動
		drawLine ();
		if(time > 3){//３秒経ったら
			transform.position = startPos;//座標を初期位置に設定
			time = 0;//時間を初期化
		}
	}

	void drawLine(){
		fingerPos = new Vector3((transform.position.x-0.6f),(transform.position.y-1.4f),0f);
		GameObject obj = Instantiate (line, fingerPos, transform.rotation) as GameObject;//オブジェクトの配置
		obj.transform.position = (startfingerPos + fingerPos)/2;//座標の位置調整
		obj.transform.right = (fingerPos - startfingerPos).normalized;//正規化
		obj.transform.localScale = new Vector3 ((fingerPos- startfingerPos).magnitude, lineWidth, lineWidth);

		Destroy(obj,0.02f);//オブジェクトの破棄
	}

}
