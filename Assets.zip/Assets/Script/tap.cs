﻿using UnityEngine;
using System.Collections;

public class tap : MonoBehaviour 
{
	void Start(){
		Debug.Log("start!");//タッチできているか
	}
	void Update(){
		if (Input.touchCount > 0) {//タッチされたかどうか
			Touch tap = Input.GetTouch (0);
			if (tap.phase == TouchPhase.Began) {//タッチ開始
				Debug.Log ("touch1" + tap.position);//タッチできているか
				Vector3 pos = Camera.main.ScreenToWorldPoint(tap.position);//タッチが終わった点を取得する
				pos.z = 0;
				Debug.Log ("touch2" + pos);//タッチできているか
			}
		}
	}
}