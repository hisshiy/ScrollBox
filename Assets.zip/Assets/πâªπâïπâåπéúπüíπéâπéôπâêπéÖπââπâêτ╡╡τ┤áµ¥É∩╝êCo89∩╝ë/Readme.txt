﻿このアセットは、『ユニティちゃんライセンス』で提供されています。
ユニティちゃんライセンス条項（html版）http://unity-chan.com/download/license.html

このアセットをご利用される場合は、『キャラクター利用のガイドライン』も併せてご確認ください。
キャラクター利用のガイドライン（html版）http://unity-chan.com/download/guideline.html

素材集を使われる方は『ユニティちゃんライセンス』、及び『キャラクター利用のガイドライン』を理解してからお使い下さい。

尚、利用に関しましては事前連絡は不要ですが、一言メールを頂けると幸いです。
以上、よろしくお願いします。

ゴコー

Mail : backlight1144@gmail.com
運営サイト Unity道しるべ(http://unity-michi.com/)